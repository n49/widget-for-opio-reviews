<?php
/*
Plugin Name: Widget for OPIO Reviews
Plugin URI: 
Description: Instantly add OPIO Reviews on your website to increase user confidence and SEO.
Version: 1.0.0
Author: Dhiraj Timalsina <dhiraj@n49.com>
Text Domain: widget-for-opio-reviews
Domain Path: /languages
*/

namespace WP_Opio_Reviews;

if (!defined('ABSPATH')) {
    exit;
}

require(ABSPATH . 'wp-includes/version.php');

define('GRW_VERSION'          , '1.0.0');
define('GRW_PLUGIN_FILE'      , __FILE__);
define('GRW_PLUGIN_URL'       , plugins_url(basename(plugin_dir_path(__FILE__ )), basename(__FILE__)));
define('GRW_ASSETS_URL'       , GRW_PLUGIN_URL . '/assets/');

require_once __DIR__ . '/autoloader.php';

/*-------------------------------- Links --------------------------------*/
function grw_plugin_action_links($links, $file) {
    $plugin_file = basename(__FILE__);
    if (basename($file) == $plugin_file) {
        $settings_link = '<a href="' . admin_url('admin.php?page=grw-builder') . '">' .
                             '<span style="background-color:#e7711b;color:#fff;font-weight:bold;padding:0px 8px 2px">' .
                                 'Connect Reviews' .
                             '</span>' .
                         '</a>';
        array_unshift($links, $settings_link);
    }
    return $links;
}
add_filter('plugin_action_links', 'WP_Opio_Reviews\\grw_plugin_action_links', 10, 2);

/*-------------------------------- Row Meta --------------------------------*/
function grw_plugin_row_meta($input, $file) {
    if ($file != plugin_basename( __FILE__ )) {
        return $input;
    }

    $links = array(
        '<a href="' . admin_url('admin.php?page=grw-support') . '" target="_blank">' . __('View Documentation', 'widget-for-opio-reviews') . '</a>',
    );
    $input = array_merge($input, $links);
    return $input;
}
add_filter('plugin_row_meta', 'WP_Opio_Reviews\\grw_plugin_row_meta', 10, 2);

/*-------------------------------- Plugin init --------------------------------*/
$grw = new Includes\Plugin();
$grw->register();

?>