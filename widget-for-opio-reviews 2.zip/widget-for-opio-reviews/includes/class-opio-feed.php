<?php namespace WP_Opio_Reviews\Includes;

class Opio_Feed {
    public function ReturnOpioHtml($business) {
        ob_start(); ?>
    <?php
        // convert the business object to an array
        // dd($business);
        $business = json_decode(json_encode($business), true);
        $writeReviewUrl = 'https://op.io/write-review/5734f48a0b64d7382829fdf7/'.$business["_id"];
        if(isset($business["landingPageUsername"])) {
            $writeReviewUrl = 'https://' .$business["landingPageUsername"]. '.op.io';
        }
    
        $opio_schema_reviews = array_filter( $business['reviews'], function($review) {
            if(isset($review['propertyId'])) {
              return $review['propertyId'] == "5734f48a0b64d7382829fdf7";
            }
          });

        $LastEvaluatedKey = null;
        if(isset($business['LastEvaluatedKey'])) {
            $LastEvaluatedKey = $business['LastEvaluatedKey'];
        }
  
  
        $arrowCalculation = strpos($business['name'], 'XYZ') !== false ? "50%" : "25%";
        $arrowCalculationGoogle = strpos($business['name'], 'XYZ') !== false ? "50%" : "75%";
        $starColor = "#ffc600";
        $bgColor = "#ffffff";
        $buttonColor = "#0078ca";
        $buttonColorText = "#ffffff";
        $contactButtonColor = "#81c684";
        $contactButtonColorText = "#ffffff";
        $fontFamily = "Roboto";
        $overviewColor = "#0078ca";
        $reviewFontColor = "#1D1D1F";
        $inactiveBorderColor = "rgb(198, 204, 211)";
        $reviewFeedUrl = null;
        if(isset($business['reviewFeedUrls']['5734f48a0b64d7382829fdf7'])){
            $reviewFeedUrl = $business['reviewFeedUrls']['5734f48a0b64d7382829fdf7'];
        } 
        $fontFamilyVal = "https://fonts.googleapis.com/css?family=Roboto:400,100,200,300,500,700";
        if(isset($business["reviewFeedSettings"]["feedStarColor"])) {
            $starColor = $business["reviewFeedSettings"]["feedStarColor"];
        }
        if(isset($business["reviewFeedSettings"]["feedBgColor"])) {
            $bgColor = $business["reviewFeedSettings"]["feedBgColor"];
        }
        if(isset($business["reviewFeedSettings"]["feedButtonColor"])) {
            $buttonColor = $business["reviewFeedSettings"]["feedButtonColor"];
        }
        if(isset($business["reviewFeedSettings"]["feedButtonTextColor"])) {
            $buttonColorText = $business["reviewFeedSettings"]["feedButtonTextColor"];
        }
        if(isset($business["reviewFeedSettings"]["feedContactButtonColor"])) {
            $contactButtonColor = $business["reviewFeedSettings"]["feedContactButtonColor"];
        }
        if(isset($business["reviewFeedSettings"]["feedContactButtonTextColor"])) {
            $contactButtonColorText = $business["reviewFeedSettings"]["feedContactButtonTextColor"];
        }
        if(isset($business["reviewFeedSettings"]["reviewFontColor"])) {
            $reviewFontColor = $business["reviewFeedSettings"]["reviewFontColor"];
        }
        $poweredByOpioLogo = false;
        if(isset($business["reviewFeedSettings"]["poweredByOpioLogo"])) {
            $poweredByOpioLogo = $business["reviewFeedSettings"]["poweredByOpioLogo"];
        }
        $providedByReseller = false;
        if(isset($business["reviewFeedSettings"]["providedByReseller"])) {
            $providedByReseller = $business["reviewFeedSettings"]["providedByReseller"];
        }
        $businessNameSetting = false;
        if(isset($business["reviewFeedSettings"]["name"])) {
            $businessNameSetting = $business["reviewFeedSettings"]["name"];
        }
        $businessLogoSetting = false;
        if(isset($business["reviewFeedSettings"]["logo"])) {
            $businessLogoSetting = $business["reviewFeedSettings"]["logo"];
        }
        $buttonBorder = "none";
        //set overview to button color unless transparent then text color
    
        if(isset($business["reviewFeedSettings"]["activeFontFamily"]["name"])) {
            $fontFamily = $business["reviewFeedSettings"]["activeFontFamily"]["name"];
            $fontFamilyVal = $business["reviewFeedSettings"]["activeFontFamily"]["value"];
            if($fontFamily == "Roboto") {
                $fontFamilyVal = "https://fonts.googleapis.com/css?family=Roboto:400,100,200,300,500,700";
            }
        }
    
        $overviewColor = $buttonColor;
        if($buttonColor == $bgColor) {
            //Transparent so set border
            $buttonBorder = "1px solid ".$buttonColorText;
            $overviewColor = $buttonColorText;
        }
    
        $reseller = NULL;
        if(isset($business["organizations"])) {
            $reseller = current(array_filter($business["organizations"], function($item) {
                return isset($item['type']) && 'reseller' == $item['type'];
            }));
        }
     ?>
     
        <head>
            <body>
                <div id="root">
                    <section>
                        <div class="outer">
                        <div class="logoContainer">
							<a href="https://op.io/" target="_blank" style="text-decoration: none;color: #1D1D1F;">
						    <div class="poweredBy">Powered by &nbsp;
								<img src="https://op.io/dashboard/graphics/opio-blue-2x.png" class="opioLogo">
						    </div>
						    </a>	
					    </div>
                        <div style="display: flex; margin-top: 30px; line-height: 16px; height: 16px;">
                        <div style="border-bottom: 1px solid #E6E8EB; height: 50%; display: inline-block; flex-grow: 1;"></div>
				        </div>
                            <div id="aggregationOpio">
                                <div class="inside1">
                                    <div id="aggregationWidgetOpio">
                                        <div class="aggregationContainer">
                                            <div class="aggregationScore">
                                                <?php echo $business['rating']; ?>
                                            </div>
                                            <div style="display:inline-block">
                                                <span>
                                                    <div style="overflow: hidden; position: relative;">
                                                        <style>
                                                            .react-stars-022156700034603038:before {
                                                            position: absolute;
                                                            overflow: hidden;
                                                            display: block;
                                                            z-index: 1;
                                                            top: 0; left: 0;
                                                            width: 50%;
                                                            content: attr(data-forhalf);
                                                            color: <?php echo $starColor ?>
                                                            }
                                                        </style>
                                                        <?php
                                                            $aggTotal = $business["aggregateRating"]["3"]["average"];
                                                            if($aggTotal > 0.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill: '.$starColor.';}</style></defs><title>yellow</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            } elseif ($aggTotal == 0.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}.cls-2{fill:'.$starColor.';}</style></defs><title>yellow-grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0m0,18.36"/><path class="cls-2" d="M12,0,8.64,8,0,8.71l6.55,5.68-2,8.44L12,18.36m0,0"/></g></g></svg></div>';
                                                            } else {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}</style></defs><title>grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            }

                                                            if($aggTotal > 1.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill: '.$starColor.';}</style></defs><title>yellow</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            } elseif ($aggTotal == 1.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}.cls-2{fill:'.$starColor.';}</style></defs><title>yellow-grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0m0,18.36"/><path class="cls-2" d="M12,0,8.64,8,0,8.71l6.55,5.68-2,8.44L12,18.36m0,0"/></g></g></svg></div>';
                                                            } else {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}</style></defs><title>grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            }

                                                            if($aggTotal > 2.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill: '.$starColor.';}</style></defs><title>yellow</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            } elseif ($aggTotal == 2.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}.cls-2{fill:'.$starColor.';}</style></defs><title>yellow-grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0m0,18.36"/><path class="cls-2" d="M12,0,8.64,8,0,8.71l6.55,5.68-2,8.44L12,18.36m0,0"/></g></g></svg></div>';
                                                            } else {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}</style></defs><title>grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            }
                                                            if($aggTotal > 3.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill: '.$starColor.';}</style></defs><title>yellow</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            } elseif ($aggTotal == 3.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}.cls-2{fill:'.$starColor.';}</style></defs><title>yellow-grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0m0,18.36"/><path class="cls-2" d="M12,0,8.64,8,0,8.71l6.55,5.68-2,8.44L12,18.36m0,0"/></g></g></svg></div>';
                                                            } else {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}</style></defs><title>grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            }

                                                            if($aggTotal > 4.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill: '.$starColor.';}</style></defs><title>yellow</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            } elseif ($aggTotal == 4.5) {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}.cls-2{fill:'.$starColor.';}</style></defs><title>yellow-grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0m0,18.36"/><path class="cls-2" d="M12,0,8.64,8,0,8.71l6.55,5.68-2,8.44L12,18.36m0,0"/></g></g></svg></div>';
                                                            } else {
                                                                echo '<div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width: 16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:#E6E8EB;}</style></defs><title>grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>';
                                                            }
                                                        ?>
                                                    </div>
                                                </span>
                                            </div>
                                            <div style="font-size: 13px; color: <?php echo $reviewFontColor ?>"><?php echo $business["aggregateRating"]["3"]["total"] ?> Reviews</div>
                                        </div>
                                        <div style="display: flex; flex-direction: row; margin-top: 15px;">
                                            <?php if(isset($business["reviewFeedSettings"]["contact"]) && $business["reviewFeedSettings"]["contact"] !== false && isset($business["contactButtonUrls"])): ?>
                                                <div id="some id" style="width: 100%; display: flex; flex-direction: row; justify-content: right; padding: 0px 8px; text-align: center;">
                                                    <a style="text-decoration: none; color:inherit" target="_blank" href="<?php echo $writeReviewUrl ?>">
                                                <div style="border-radius: 2px; display: inline-block; height: 40px; line-height: 40px; margin-left: 0px; text-align: center; cursor: pointer; padding: 0px; font-weight: 500; font-size: 14px; color: <?php echo $contactButtonColorText ?>; border: <?php echo $buttonBorder ?>; background-color: <?php echo $contactButtonColor ?>; width: 150px; position: relative; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1); user-select: none;"><div style="display: inline-block; position: relative; height: 100%;">
                                                    <span>Write a review</span>
                                                </div></div></a>
								        </div>
                                        <?php $contactUrl = $business["contactButtonUrls"][$business["reviewFeedSettings"]["contact"]];
                                            //if contactUrl doesn't have http or https add https
                                            if(strpos($contactUrl, 'http') !== true) {
                                                $contactUrl = "https://".$contactUrl;
                                            }
                                        ?>


                                            <div id="some-id" style="width: 100%; display: flex; flex-direction: row; justify-content: left; padding: 0px 8px; text-align: center;">
                                                <a style="text-decoration: none; color:inherit" target="_blank" href="<?php echo $contactUrl ?>">
                                            <div style="border-radius: 2px; display: inline-block; height: 40px; line-height: 40px; margin-left: 0px; text-align: center; cursor: pointer; padding: 0px; font-weight: 500; font-size: 14px; color: <?php echo $contactButtonColorText ?>; border: <?php echo $buttonBorder ?>; background-color: <?php echo $contactButtonColor ?>; width: 150px; position: relative; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1); user-select: none;"><div style="display: inline-block; position: relative; height: 100%;">
                                                <span><?php echo $business["reviewFeedSettings"]["contact"] ?></span>
                                            </div></div></a>
								        </div>
                                        <?php else : ?>
                                            <div id="some id" style="width: 100%; display: flex; flex-direction: row; justify-content: center; padding: 0px 8px; text-align: center;">
                                                <a style="text-decoration: none; color:inherit" target="_blank" href="<?php echo $writeReviewUrl ?>">
                                            <div style="border-radius: 2px; display: inline-block; height: 40px; line-height: 40px; margin-left: 0px; text-align: center; cursor: pointer; padding: 0px; font-weight: 500; font-size: 14px; color: <?php echo $contactButtonColorText ?>; border: <?php echo $buttonBorder ?>; background-color: <?php echo $contactButtonColor ?>; width: 150px; position: relative; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1); user-select: none;"><div style="display: inline-block; position: relative; height: 100%;">
							 			        <span>Write a review</span>
								            </div></div></a>
								        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div style="display: flex; margin-top: -10px; margin-bottom: 30px; line-height: 16px; height: 16px;">
						            <div style="border-bottom: 1px solid #E6E8EB; height: 50%; display: inline-block; flex-grow: 1;"></div>
					            </div>
                                <div id="entireReviewDiv">
                                    <?php 
                                        $all_reviews = new Feed\Opio_Review();
                                        echo $all_reviews->get_reviews($business, $starColor, $buttonBorder, $buttonColor, $buttonColorText);
                                    ?>
                                </div>
                        </div>
                    </section>
                </div>
            </body>
        </head>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>
        <script type="text/javascript">
document.addEventListener("DOMContentLoaded", function() {
	localStorage.clear();
	localStorage.setItem('calledReview', 20);
	});
	window.nextPageToken = <?php echo json_encode($LastEvaluatedKey) ?>;


</script>

<script id="jsonldSchema" type="application/ld+json">
    
    <?php $count=1; ?>
    {
        "@context": "http://schema.org",
        "@type": "Product",
        "name": "<?php echo $business["name"]?>",
        "image": "https://op.io/wp-content/uploads/2018/06/cropped-opio2-blue.png",
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "<?php echo $business['aggregateRating']['3']['average']; ?>",
            "reviewCount": "<?php echo $business['aggregateRating']['3']['total']; ?>"
        },
        "review": [
            <?php foreach($opio_schema_reviews as $key => $review) { ?>

            {
                "@type": "Review",
                "author": {
                    "@type": "Person",
                    "name": "<?php echo $review['user']['firstName']; ?>"
                },
                "datePublished": "<?php date('M d, Y', $review["dateCreated"]/1000); ?>",
                "reviewBody": "<?php echo $review['content']; ?>",
                "reviewRating": {
                    "@type": "Rating",
                    "ratingValue": "<?php echo $review['rating']; ?>"
                },
                "publisher": {
                    "@type": "Organization",
                    "name": "op.io",
                    "sameAs": "https://www.op.io"
                }
            }
            <?php if($count < count($opio_schema_reviews)){
                echo ",";
            } 
            ?>
            <?php $count = $count + 1; ?>
            
            <?php } ?>
        ]
    }
</script>
        <style>
            @media (min-width: 300px) and (max-width: 360px) {
    .verifiedByContainer {
        display: inline-block; 
        padding-left: 3px; 
        padding-right: 10px; 
        border-radius: 11px; 
        color: <?php echo $reviewFontColor; ?>;
        background-color: #E6E8EB; 
        height: 22px; 
        margin-left: 0;
        margin-top: 5px; 
        font-size: 10px;
        font-weight: 400;
    }

    .empTagContainer {
        display: grid; 
        grid-template-rows: auto; 
        grid-template-columns: auto;
        margin-top: 10px; 
        margin-bottom: 10px; 
        grid-gap: 10px;
    }

}
.verifiedByContainer {
        display: inline-block; 
        padding-left: 3px; 
        padding-right: 10px; 
        border-radius: 11px; 
        color: <?php echo $reviewFontColor; ?>;
        background-color: #E6E8EB; 
        height: 22px; 
        margin-left: 5px;
        margin-top: 5px; 
        font-size: 10px;
        font-weight: 400;
    }
        </style>
    <?php 
        return ob_get_clean();
    }

}

?>
