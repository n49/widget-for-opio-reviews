<?php

namespace WP_Opio_Reviews\Includes;

class Opio_Handler {

    public function __construct($entity_id, $entity_type) {
        $this->entity_id = $entity_id;
        $this->entity_type = $entity_type;
    }

    public function get_business() {
        $ent_id = $this->entity_id;
        $ent_type = $this->entity_type;
        // dd($ent_id, $ent_type);
        if($ent_type == 'allReviewFeed') {
            $biz_url = "https://op.io/api/entities/mixreviews?entityId=${ent_id}";
            // increase the timeout
            $args = array(
                'timeout' => 500,
                'headers' => array(
                    'content-type' => 'application/json',
                    'Authorization' => 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOjE2NDQzNDY2MzEsInVzZXJfaWQiOiJrdHN4dzlramxkZ3RzZDNqMSIsImV4cCI6MTI5NzY0NDM0NjYzMX0.FZeMMsZlix1eQ1aJFmQ0MV_L_ezFb4RhrqCIhceTT-w'
                ),
            );
            $business_request = wp_remote_post($biz_url, $args);
            $business = json_decode($business_request['body']);
        }
        else {
            $biz_url = "https://op.io/api/entities/${ent_id}?propertyId=5734f48a0b64d7382829fdf7&skip=0&limit=25&removeFilters=reviewStatus";
            $args = array(
                'timeout' => 500,
                'headers' => array(
                    'content-type' => 'application/json',
                    'Authorization' => 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6IjU3MmE0NDI3NDdhYjg5YzkzYzE0MzVlNV9UVG55Z2E0NEBvcC5pbyIsInVzZXJfbWV0YWRhdGEiOnsiX2lkIjoiajJnZWdwYzhzZnd3Y2NzYWcifSwiaXNzIjoiaHR0cHM6Ly9vcC5pby8iLCJzdWIiOiJhcGlrZXl8ajJnZWdwYzhzZnd3Y2NzYWciLCJhdWQiOiJobTNsZmlvUHAwVWhqQnNkV0V6MG9nTW9zVVNDV2p3SCIsImV4cCI6MjE0NTkxNjgwMCwiaWF0IjoxNDk0MjY0NDM1LCJyZXNvdXJjZXMiOlt7InJvdXRlIjoiZW50aXRpZXMifSx7InJvdXRlIjoicHJvcGVydGllcyIsInF1ZXJ5IjpbbnVsbF19XX0.IGrh8vnO1o9SLfmhuEzPNSkiLYhsxcIvti9Pq-9N65s'
                ),
            );
            $business_request = wp_remote_get($biz_url, $args);
            $business = json_decode($business_request['body']);
            // check if business is array if yes use the first one
            if(is_array($business)) {
                $business = $business[0];
            }
            
            // dd($business_request);
        }
        // use wp_remote_post to send the request and also set headers
        // catch error 
        if (is_wp_error($business_request)) {
            $error_message = $business_request->get_error_message();
            echo "Something went wrong: $error_message";
            return;
        }
        // dd($business);
        if(!$business->reviews) {
            echo "Sorry! This entity doesn't have all reviews feed enabled";
            return;
        }
        // dd($business);
        $opio_feed = new Opio_Feed();
        $html_biz = $opio_feed->ReturnOpioHtml($business);
       
        return $html_biz;
    }

    public function render_reviews() {
        $business = $this->get_business();
        $reviews_html = '';
        foreach ($reviews as $review) {
            $reviews_html .= $this->render_review($review);
        }
        return $reviews_html;
    }


}