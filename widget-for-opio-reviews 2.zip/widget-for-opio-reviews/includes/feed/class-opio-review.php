<?php

namespace WP_Opio_Reviews\Includes\Feed;

class Opio_Review {
    public function get_reviews($business, $starColor, $buttonBorder, $buttonColor, $buttonColorText) {
        ob_start();
        $reviewFontColor = "#1D1D1F";
        if(isset($business["reviewFeedSettings"]["reviewFontColor"])) {
            $reviewFontColor = $business["reviewFeedSettings"]["reviewFontColor"];
        }

        $LastEvaluatedKey = null;
        if(isset($business['LastEvaluatedKey'])) {
          $LastEvaluatedKey = $business['LastEvaluatedKey'];
        }
  
        
        foreach($business['reviews'] as $k => $_rev):

            $user = $_rev["user"]; $comments = $_rev["comments"] ?? []; $appendHr = ''; if($k > 0) { $appendHr = '<div class="opioHR"> </div>'; } ?>

            <?php echo $appendHr ?>
            <div id="<?php echo $_rev["_id"] ?>" style="display: flex; position: relative;">
                <div style="vertical-align: top; padding-right: 20px;">
                    <div id="outer" style="display: inline-block;">
                        <?php if(isset($user["userPic"]["imageId"])): ?>
                            <div id="inner" style="width: 50px; height: 50px; line-height: 50px; border-radius: 50%; color: <?php echo $reviewFontColor ?>;font-size: 24px; text-align: center; background-size: cover; background-repeat: no-repeat; background-image: url(https://images.files.ca/200x200/<?php echo $user["userPic"]["imageId"]?>.jpg?nocrop=1);">
                            </div>
                        <?php else: ?>
                            <?php if(isset($user["userPic"]) && $user["userPic"] != "") : ?>
                                <div id="inner"
                                    style="width: 50px; height: 50px; line-height: 50px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 24px; text-align: center; background-size: cover; background-repeat: no-repeat; background-image: url(<?php echo $user["userPic"] ?>);">
                                </div>
                            <?php else: ?>
                                <div id="inner"
                                    style="width: 50px; height: 50px; line-height: 50px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 24px; text-align: center; background-size: cover; background-repeat: no-repeat; background-color: #dddddd">
                                    <?php echo mb_substr(ucfirst($user["firstName"]), 0, 1, 'utf-8') ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div id="<?php echo $_rev["_id"]?>-reviewContainer" style="vertical-align: top; flex-grow: 1;">
                    <div style="margin-bottom: 10px;">
                        <div>
                            <?php if(isset($_rev["mixPinned"]) && $_rev["mixPinned"] === "true"): ?>
                                <div style="font-size: 12px; color: <?php echo $reviewFontColor ?>;">
                                    <div style="display: flex;">
                                        <div style="width: 8px; margin-right: 6px;">
                                            <svg id="Layer_2" data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 11.94">
                                                <defs>
                                                    <style>
                                                    .cls-1 {
                                                        fill: <?php echo $reviewFontColor; ?>;
                                                    }
                                                    </style>
                                                </defs>
                                                <g id="Layer_12" data-name="Layer 12">
                                                    <path class="cls-1" d="m7.99,8.59c-.17-.74-.88-1.37-1.93-1.75l.71-4.2h.33c.2,0,.35-.16.35-.35V.35c0-.2-.16-.35-.35-.35H.89c-.2,0-.35.16-.35.35v1.92c0,.2.16.35.35.35h.33l.68,4.22h0C.87,7.23.18,7.86,0,8.59c-.03.11,0,.22.07.3s.17.13.28.13h2.85l.35,2.59c0,.19.17.34.35.34h.19c.19,0,.34-.15.35-.34l.35-2.59h2.85c.11,0,.21-.05.28-.13.07-.08.09-.2.07-.3Z"/>
                                                </g>
                                            </svg>
                                        </div>
                                        <span>Pinned Review</span>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if($_rev['propertyInfo']['name'] === 'facebook') : ?>
                                <?php if($_rev['rating'] === 'positive') : ?>
                                    <div style="display: inline-flex; margin-bottom: 5px; align-items: center; vertical-align: middle;">
                                        <img style="padding-right: 5px; width: 100%; height: 100%; padding-top: 2px;" src="https://op.io/dashboard/graphics/facebook-recommends.png" />
                                        <p style="margin: 0; font-weight: 500; font-size: 13px; white-space: nowrap;">Recommends</p>
                                    </div>
                                <?php else : ?>
                                    <div style="display: inline-flex; margin-bottom: 5px; align-items: center; vertical-align: middle;">
                                        <img style="padding-right: 5px; width: 100%; height: 100%; padding-top: 2px;" src="https://op.io/dashboard/graphics/facebook-recommends-grey.png" />
                                        <p style="margin: 0; font-weight: 500; font-size: 13px; white-space: nowrap;">Doesn't Recommend</p>
                                    </div>
                                <?php endif; ?>

                            <?php else: ?>
                                <div style="overflow: hidden; position: relative;">
                                    <style>
                                        .react-stars-04811029757080685:before {
                                            position: absolute;
                                            overflow: hidden;
                                            display: block;
                                            z-index: 1;
                                            top: 0;
                                            left: 0;
                                            width: 50%;
                                            content: attr(data-forhalf);
                                            color: <?php echo $starColor ?>;
                                        }
                                    </style>
                                    

                                    <?php $ratingsCheck = [0.5, 1.5, 2.5, 3.5, 4.5]; ?>

                                    <?php foreach($ratingsCheck as $rating) : ?>
                                        <?php if($_rev['rating'] > $rating) : ?>
                                        <div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width:16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-1{fill:<?php echo$starColor?>;}</style></defs><title>yellow</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>
                                        <?php else : ?>
                                            <?php if($_rev['rating'] == $rating) : ?>
                                                <div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width:16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str-2{fill:#E6E8EB;}.str-1{fill:<?php echo$starColor?>;}</style></defs><title>yellow-grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str-2" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0m0,18.36"/><path class="str-1" d="M12,0,8.64,8,0,8.71l6.55,5.68-2,8.44L12,18.36m0,0"/></g></g></svg></div>
                                            <?php else : ?>
                                                <div style="position: relative; overflow: hidden; cursor: pointer; display: block; float: left; width:16px; height: 22px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.04 22.83"><defs><style>.str0-1{fill:#E6E8EB;}</style></defs><title>grey</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="str0-1" d="M12,18.36l7.43,4.48-2-8.44L24,8.71,15.39,8,12,0,8.64,8,0,8.71l6.55,5.68-2,8.44Zm0,0"/></g></g></svg></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                                                
                        <?php if(!isset($user['lastName'])) {$user['lastName'] = '';} ?>

                        <div style="font-weight: 400; font-size: 12px; color: <?php echo$reviewFontColor?>; display: flex; flex-wrap: wrap; align-items: center;"><span>By  </span>
                            <?php
                                $verifiedByStatus = ''; 
                                if(array_key_exists('userPic', $_rev["user"]) && gettype($_rev["user"]["userPic"]) !== 'undefined' && gettype( $_rev["user"]["userPic"]) !== 'object' && !is_array($_rev["user"]["userPic"]) && str_contains($_rev["user"]["userPic"], 'fb') && !(str_contains($_rev["user"]["userPic"], 'google'))) {
                                    $verifiedByStatus = 'facebook';
                                } else if(array_key_exists('userPic', $_rev["user"]) && gettype($_rev["user"]["userPic"]) !== 'undefined' && gettype($_rev["user"]["userPic"]) !== 'object' && !is_array($_rev["user"]["userPic"]) && str_contains($_rev["user"]["userPic"], 'google')) {
                                    $verifiedByStatus = 'google';
                                } else if(isset($_rev["user"]["email"]) && str_contains($_rev["user"]["email"], 'op.io') || (isset($_rev["user"]["verifiedStatus"]) && $_rev["user"]["verifiedStatus"] == 'guest')) {
                                    $verifiedByStatus = 'business';
                                } else if($_rev["status"] == 'guest'){
                                    $verifiedByStatus = 'Guest';
                                } 														
                                else {
                                    $verifiedByStatus = 'email';
                                }
                                    
                            ?>
                        <?php if($verifiedByStatus == 'Guest' || isset($_rev["user"]["verifiedStatus"]) && $_rev["user"]["verifiedStatus"] === 'guest' || $_rev["propertyId"] === 1 || $_rev["propertyId"] === 2) { ?>
                            <a style="font-weight: 500; text-decoration: none; color: <?php echo $reviewFontColor ?>; border-bottom: none;"><span style="margin-left: 3px;"><?php echo $user["firstName"] . ' ' . $user["lastName"] ?></span></a><span style="margin-left: 3px;"> on <?php echo date('M d, Y', $_rev["dateCreated"]/1000) ?></span>
                        <?php } else { ?>
                            <a target="_blank" href="https://op.io/member/<?php echo $user['user_id'] ?? '' ?>/" style="font-weight: 500; text-decoration: none; color: <?php echo $reviewFontColor ?>; border-bottom: none;"><span style="margin-left: 3px;"><?php echo $user["firstName"] . ' ' . $user["lastName"] ?></span></a><span style="margin-left: 3px;"> on <?php echo date('M d, Y', $_rev["dateCreated"]/1000) ?></span>
                        <?php } ?>
                        <div class="verifiedByContainer" >
                            <div style="display: flex; flex-wrap: wrap; align-items: center;">
                                <div style="display: flex; flex-wrap: wrap; align-items: center; width: 15px; height: 22px; vertical-align: middle; margin-right: 2px;">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14">
                                        <defs>
                                            <style>.cls-1{fill: <?php echo $reviewFontColor ?>;}</style>
                                        </defs>
                                        <title>Asset 1</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M7,0a7,7,0,1,0,7,7A7,7,0,0,0,7,0Zm3.18,5.64L6.51,9.31a.67.67,0,0,1-.47.2.69.69,0,0,1-.48-.2L3.82,7.56a.63.63,0,0,1-.2-.47.68.68,0,0,1,1.15-.48L6,7.88,9.23,4.69a.68.68,0,0,1,1.15.48A.65.65,0,0,1,10.18,5.64Z"/></g></g>
                                    </svg>
                                </div>
                                <?php if($_rev["status"] == 'guest') : ?>
                                    <span style="vertical-align: middle;">Guest Review</span> 
                                <?php else : ?>
                                    <span style="vertical-align: middle;">Verified by <?php echo $verifiedByStatus ?></span> 
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 10px;"></div>
                    <div style="margin-bottom: 10px;"></div>
                    <div class="reviewTextColor" style="white-space: pre-wrap; font-size: 14px; line-height: 1.5em; color: <?php echo $reviewFontColor ?>;"><?php echo $_rev['content'] ?></div>
                    
                    <?php if(isset($_rev["taggedEmployees"]) && count($_rev["taggedEmployees"]) > 0) : ?>
                        <div class="empTagContainer">
                            <?php foreach($_rev["taggedEmployees"] as $emp)	: ?>
                                <?php 
                                    $position = ""; 
                                    $entityId = $_rev["entityId"];
                                    if(isset($emp['position_title'])) {
                                        if(count($emp["position_title"]) !== 0) {
                                            $posIndex = '';
                                            foreach($emp["position_title"] as $key => $value) {
                                                if(isset($value["entityId"]) && $value["entityId"] === $entityId) {
                                                    $posIndex = $key;
                                                }
                                            }
                                            if($posIndex !== '') {
                                                if(isset($emp["position_title"][$posIndex]["position"])) {
                                                    if(!is_array($emp["position_title"][$posIndex]["position"])) {
                                                        $position = $emp["position_title"][$posIndex]["position"];
                                                    }
                                                }																	
                                            }
                                        }
                                    }
                                ?>
                                <div class="empTagCard">
                                    <?php if(isset($emp["userPic"]["imageId"])) : ?>
                                        <div id="inner" style="width: 35px; height: 35px; line-height: 35px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 24px; text-align: center; background-size: cover; background-repeat: no-repeat; background-image: url(https://images.files.ca/200x200/<?php echo $emp["userPic"]["imageId"]?>.jpg?nocrop=1);"></div>
                                    <?php else : ?>
                                        <?php if(isset($emp["userPic"]) && $emp["userPic"] != "") : ?>
                                            <div id="inner" style="width: 35px; height: 35px; line-height: 35px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 24px; text-align: center; background-size: cover; background-repeat: no-repeat; background-image: url(<?php echo $emp["userPic"]?>);"></div>
                                        <?php else : ?>
                                            <div id="inner" style="width: 35px; height: 35px; line-height: 35px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 24px; text-align: center; background-size: cover; background-repeat: no-repeat; background-color: #dddddd"><?php echo mb_substr(ucfirst($emp["firstName"]), 0, 1, 'utf-8')?></div>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($position === '') : ?>
                                        <div style="display: grid; grid-template-rows: 25px">
                                            <span style="align-self: end; justify-self: left; margin-left: 10px; color: <?php echo $reviewFontColor ?>; font-size: 14px">
                                                <?php if(isset($emp['firstName']) && isset($emp['lastName'])) : ?>
                                                    <?php echo $emp['firstName'] . ' ' . mb_substr(ucfirst($emp['lastName']), 0, 1, 'utf-8') ?>
                                                <?php elseif(isset($emp['firstName']) && !isset($emp['lastName'])) : ?>
                                                    <?php echo $emp['firstName'] ?>
                                                <?php else : ?>
                                                    ''
                                                <?php endif; ?>
                                            </span> 
                                        </div>
                                    <?php else : ?>
                                        <div style="display: grid; grid-template-rows: 20px 15px">
                                            <span style="align-self: end; justify-self: left; margin-left: 10px; color: <?php echo $reviewFontColor ?>; font-size: 14px">
                                                <?php if(isset($emp['firstName']) && isset($emp['lastName'])) : ?>
                                                    <?php echo $emp['firstName'] . ' ' . mb_substr(ucfirst($emp['lastName']), 0, 1, 'utf-8') ?>
                                                <?php elseif(isset($emp['firstName']) && !isset($emp['lastName'])) : ?>
                                                    <?php echo $emp['firstName'] ?>
                                                <?php else : ?>
                                                    ''
                                                <?php endif; ?>
                                            </span> 
                                            <span style="align-self: top; justify-self: left; margin-left: 10px; margin-top: -2px; color: <?php echo$reviewFontColor?>; font-size: 12px">
                                                <?php echo $position ?>
                                            </span> 
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    <div id="media-container" style="padding-bottom: 10px;">
                        <div id="largerevimg-<?php echo $_rev['_id'] ?>"></div>

                            <?php if($_rev["images"] !== null) : ?>
                                <?php foreach($_rev["images"] as $image) : ?>
                                    <?php if(isset($image['imageId'])) : ?>
                                        <a onclick="displayLargeImage('<?php echo $image['imageId'] ?>', '<?php echo $_rev['_id']?>')" style="border-bottom: none;">
                                            <div style="display: inline-block; width: 72px; height: 72px; background-position: center center; background-size: cover; background-repeat: no-repeat; margin: 5px; text-align: center; background-image: url(https://images.files.ca/200x200/<?php echo $image['imageId'] ?>.jpg?nocrop=1);">
                                            </div>
                                        </a>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endif; ?>

                            <?php if($_rev["videos"] !== null) : ?>
                                <?php foreach($_rev["videos"] as $video) : ?>
                                    <div>
                                        <video preload="auto" controls=""
                                        style="width: 100%; height: auto; margin: 5px; transition: width 1s ease-out 0s, height 1s ease-out 0s;">
                                        <source src="https://videocdn.n49.ca/mp4sdpad480p/<?php echo $video['videoId']?>.mp4#t=0.1"
                                        type="video/mp4"></video>

                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <div style="display: inline-block; margin-top: 10px; margin-bottom:10px;"></div>
                        
                        <?php if(isset($_rev["entityInfo"]["reviewFeedUrls"]["5734f48a0b64d7382829fdf7"])) :?>
                            <div style="color: rgb(170, 170, 170); height: 20px; line-height: 20px; display: flex; margin-top: 10px; float: right; right: 0px;">
                                <span style="color: <?php echo$reviewFontColor?>;; font-size: 14px;">Share</span>
                                <a style="display: flex; cursor: pointer; margin-left: 5px;" onclick="shareFacebookUrl('<?php echo$_rev["entityInfo"]["reviewFeedUrls"]["5734f48a0b64d7382829fdf7"]?>', '<?php echo$_rev["_id"]?>')">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <defs>
                                            <style>.cls-1{fill:<?php echo $reviewFontColor; ?>;}</style>
                                        </defs>
                                        <title>Asset 1</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M10,0A10,10,0,1,0,20,10,10,10,0,0,0,10,0Zm2.14,10h-1.4v5H8.66V10h-1V8.24h1V7.1A2,2,0,0,1,10.76,5H12.3V6.72H11.18a.42.42,0,0,0-.44.48v1h1.58Z"/></g></g>
                                    </svg>
                                </a>
                                <a style="display: flex; cursor: pointer; margin-left: 3px;" onclick="shareTwitterUrl('<?php echo$_rev["entityInfo"]["reviewFeedUrls"]["5734f48a0b64d7382829fdf7"]?>', '<?php echo$_rev["_id"]?>')">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                        <defs><style>.cls-1{fill: <?php echo $reviewFontColor; ?>;}</style></defs>
                                        <title>Asset 2</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M10,0A10,10,0,1,0,20,10,10,10,0,0,0,10,0Zm4,8v.27a5.84,5.84,0,0,1-9,4.91,3.91,3.91,0,0,0,.49,0A4.12,4.12,0,0,0,8,12.29a2,2,0,0,1-1.92-1.42,2.47,2.47,0,0,0,.39,0,2,2,0,0,0,.54-.07,2.06,2.06,0,0,1-1.65-2v0a2.08,2.08,0,0,0,.93.25,2,2,0,0,1-.91-1.71,2,2,0,0,1,.28-1A5.84,5.84,0,0,0,9.92,8.46,2.42,2.42,0,0,1,9.87,8a2.05,2.05,0,0,1,2.05-2,2.07,2.07,0,0,1,1.5.64,4.07,4.07,0,0,0,1.3-.49,2,2,0,0,1-.9,1.13A4.2,4.2,0,0,0,15,6.9,4.11,4.11,0,0,1,14,8Z"/></g></g>
                                    </svg>
                                </a>
                            </div>
                        <?php endif; ?>

                        <div id='writecomment2-<?php echo $_rev['_id'] ?>' style="display: none; width: 100%">
                            <div style="margin-top: 15px;">
                                <div>
                                    <div
                                        style="display: inline-block; margin-top: 0px; position: relative; vertical-align: top; text-align: left; width: 100%; padding-left: 0px;">
                                        <textarea id='writecomment2-<?php echo $_rev['_id']?>-textarea'
                                            placeholder="Type your comment here"
                                            style="line-height: 1.5em; border: 1px solid rgb(221, 221, 221); outline: none; width: 100%; height: 47px; color: <?php echo $reviewFontColor ?>; font-size: 14px; background-color: transparent; border-radius: 4px; min-height: 100px; padding: 12px;"></textarea>
                                    </div>
                                </div>
                            <div style="text-align: right; margin-top: 20px;">
                                <div style="text-align: left;">
                                    <div
                                        style="position: relative; display: inline-block; max-width: 100%; min-width: 100px; line-height: 18px; color: <?php echo $reviewFontColor ?>; text-align: left; height: auto; float: left;">
                                        <select
                                            style="width: 100%; background-color: transparent; max-height: 200px; overflow-y: auto; z-index: 10; height: 34px; border: 1px solid rgb(192, 199, 205); outline: none; font-size: 14px; position: relative; border-radius: 1px; -webkit-appearance: none; padding-left: 8px; padding-right: 23px; line-height: 1em;">
                                            <option hover="[object Object]" value="Comment as"
                                                style="cursor: pointer; width: 100%; vertical-align: top; padding: 6px; line-height: 20px; text-transform: capitalize; font-size: 14px;">
                                                Comment as</option>
                                            <option hover="[object Object]" value="<?php echo $cookiedUser[0]["fullName"] ?>"
                                                style="cursor: pointer; width: 100%; vertical-align: top; padding: 6px; line-height: 20px; text-transform: capitalize; font-size: 14px;">
                                                <?php echo $cookiedUser[0]["fullName"] ?></option>
                                        </select><svg viewBox="0 0 24 24"
                                            style="display: inline-block; color: rgba(0, 0, 0, 0.87); fill: currentcolor; height: 24px; width: 24px; user-select: none; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0ms; position: absolute; top: 50%; right: 4px; transform: translateY(-50%);">
                                            <path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z"></path>
                                        </svg></div>
                                </div>
                                <div
                                    style="border-radius: 2px; display: inline-block; height: 40px; line-height: 40px; margin-left: 0px; text-align: center; cursor: pointer; padding: 0px; font-weight: 300; font-size: 14px; color: rgb(0, 120, 202); background-color: transparent; position: relative; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0s; user-select: none;">
                                    <a
                                        onclick="toggle('writecomment2-<?php echo $_rev['_id'] ?>'); toggle('writecomment-<?php echo $_rev['_id']?>')">
                                        <div style="display: inline-block; position: relative; height: 100%;">Cancel</div>
                                    </a></div><a onclick="commentAs('<?php echo $_rev['_id'] ?>')"
                                    style="text-decoration: none; color: inherit">
                                    <div
                                        style="border-radius: 2px; display: inline-block; height: 40px; line-height: 40px; margin-left: 20px; text-align: center; min-width: 100px; cursor: pointer; padding: 0px 30px; font-weight: 300; font-size: 14px; color: <?php echo $reviewFontColor ?>; background-color: rgb(0, 120, 202); position: relative; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0s; user-select: none;">
                                        <div style="display: inline-block; position: relative; height: 100%;">Comment</div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 10px;"></div>
                            <?php foreach($comments as $comment) : ?>
                            <?php if(isset($comment["status"])) : ?><div> </div>
                            <?php else : ?>
                            <?php
                            if(isset($comment["entities"][0])) {
                                $commentUserLastName = "";
                            } else if(isset($comment["users"][0]["lastName"])) {
                                $commentUserLastName = $comment["users"][0]["lastName"];
                            } else {
                                $commentUserLastName = "";
                            }
                            if(isset($comment["entities"][0])) {
                                $commentUserFirstName = $comment["entities"][0]["name"];
                            } else if(isset($comment["users"][0]["firstName"])) {
                                $commentUserFirstName = $comment["users"][0]["firstName"];
                            } else {
                                $commentUserFirstName = "";
                            }
                            ?>
                            

                        <div style="margin-top: 10px; font-size: 12px;">
                            <div id="<?php echo $comment["_id"] ?>" style="display: flex; position: relative; margin-bottom: 20px">
                                <div style="vertical-align: top; padding-right: 10px;">
                                    <div id="outer" style="display: inline-block;">

                                        <?php if(isset($comment["users"][0]["userPic"]["imageId"])) : ?>
                                            <?php $imageId = $comment["users"][0]["userPic"]["imageId"]; ?>
                                                <div id="inner"
                                                style="width: 30px; height: 30px; line-height: 30px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 18px; text-align: center; background-position: center center; background-size: contain; background-repeat: no-repeat; background-image: url(https://images.files.ca/200x200/<?php echo $imageId ?>.jpg?nocrop=1);">
                                                </div>

                                        <?php elseif($_rev["propertyInfo"]["name"] === "facebook" && isset($comment["users"][0]["userPic"])) : ?>
                                            <?php $imageId = $comment["users"][0]["userPic"]; ?>
                                                <div id="inner"
                                                    style="width: 30px; height: 30px; line-height: 30px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 18px; text-align: center; background-position: center center; background-size: contain; background-repeat: no-repeat; background-image: url(<?php echo $imageId ?>);">
                                                </div>

                                        <?php elseif(isset($comment["users"][0]["firstName"])) : ?>
                                            <div id="inner"
                                                style="width: 30px; height: 30px; line-height: 30px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 18px; text-align: center; background-position: center center; background-size: contain; background-repeat: no-repeat; background-color: #dddddd">
                                                <?php echo$commentUserFirstName?> </div>

                                        <?php elseif(isset($_rev["entityInfo"]["logo"]["imageId"])) : ?>
                                            <?php $imageId = $_rev["entityInfo"]["logo"]["imageId"]; ?>
                                            <div id="inner"
                                            style="width: 30px; height: 30px; line-height: 30px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 18px; text-align: center; background-position: center center; background-size: contain; background-repeat: no-repeat; background-image: url(https://images.files.ca/200x200/<?php echo $imageId ?>.jpg?nocrop=1);">
                                            </div>

                                        <?php elseif(isset($_rev["entityInfo"]["logo"])) : ?>
                                            <?php $imageId = $_rev["entityInfo"]["logo"]; ?>
                                            <div id="inner"
                                            style="width: 30px; height: 30px; line-height: 30px; border-radius: 50%; color: <?php echo $reviewFontColor ?>; font-size: 18px; text-align: center; background-position: center center; background-size: contain; background-repeat: no-repeat; background-image: url(<?php echo $imageId ?>);">
                                        </div>
                                        <?php endif ; ?>
                                    </div>
                                </div>
                                <div style="vertical-align: top; flex-grow: 1;">
                                    <div style="font-weight: 400; margin-bottom: 10px; color: <?php echo $reviewFontColor ?>;">By
                                        <?php if(isset($comment["users"][0]) && isset($comment["users"][0]["userPic"])) : ?>
                                            <a class="nativefeed"
                                            style="font-weight: 500; text-decoration: none; color: <?php echo $reviewFontColor ?>; border-bottom: none;"><?php echo $commentUserFirstName ?>
                                            <?php echo $commentUserLastName ?></a> on <?php echo  date('M d, Y', $comment["dateCreated"]/1000)  ?>
                                        <?php else : ?>
                                            <a class="nativefeed"
                                                style="font-weight: 500; text-decoration: none; color: <?php echo $reviewFontColor ?>; border-bottom: none;"><?php echo $_rev["entityInfo"]["name"] ?>
                                            </a> on <?php echo  date('M d, Y', $comment["dateCreated"]/1000)  ?>
                                        <?php endif; ?>
                                    </div>
                                    <div id="<?php echo $comment["_id"] ?>-textareaContent"
                                    style="font-size: 14px; white-space: pre-wrap; line-height: 1.5em;"><?php echo $comment["content"] ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    <?php 
                        $imageUrl = "https://images.files.ca/200x200/" . $_rev["propertyInfo"]["logo"]["imageId"]  . ".jpg?nocrop=1";
                        // $imageUrl = str_replace(" ", "%20", $imageUrl);
                        // var_dump($imageUrl);
                            ?>
                    <?php if($_rev["propertyInfo"]["name"] === "facebook") : ?>
                        <?php if(isset($_rev["mixPinned"]) && $_rev["mixPinned"] === "true") : ?>
                          
                            <div style="position: absolute; right: 0px; top: 15px; display: flex; text-align: right; min-width: 75px; min-height: 24px; background-size: contain; background-position: center center; background-repeat: no-repeat; margin-right: 0px; background-image: url(<?php echo $imageUrl;?>); "></div>
                        <?php else : ?>
                            <div style="position: absolute; right: 0px; top: 2px; display: flex; text-align: right; min-width: 75px; min-height: 24px; background-size: contain; background-position: center center; background-repeat: no-repeat; margin-right: 0px; background-image: url(<?php echo $imageUrl;?>); "></div>
                        <?php endif; ?>
                    <?php else : ?>
                        <?php if(isset($_rev["mixPinned"]) && $_rev["mixPinned"] === "true") : ?>
                            <div style="position: absolute; right: 0px; top: 15px; display: flex; text-align: right; min-width: 100px; min-height: 24px; background-size: contain; background-position: center center; background-repeat: no-repeat; margin-right: -19px; background-image: url(<?php echo $imageUrl;?>);  "></div>
                        <?php else : ?>
                            <div style="position: absolute; right: 0px; top: 2px; display: flex; text-align: right; min-width: 100px; min-height: 24px; background-size: contain; background-position: center center; background-repeat: no-repeat; margin-right: -19px; background-image: url(<?php echo $imageUrl;?>); "></div>
                        <?php endif; ?>
                    <?php endif ;?>
                </div>
                
            </div>


            <?php if(isset($business['ads']) && isset($business['ads']['activeAd']) &&  $business['ads']['activeAd'] && $k+1 == $business['ads']['adReviewAppear'] || substr($k+1,-1) === substr($business['ads']['adReviewAppear'],-1)) : ?>
            <div>
                <script>
                    function myFunction() {
                        window.open("<?php echo $business['ads']['adButtonURL'] ?>", 'blank');
                    }
                </script>
                <?php if($business['ads']['adStyle'] == 'upload') : ?>
                <div class="opio-ad" id="businessAd" onclick="myFunction()"
                    style="margin-top: 5%; margin-bottom: 5%; cursor: pointer; background-position: center; background-repeat: no-repeat; background-size: cover; width: 100%; height: 175px; box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2); border: 1px solid #8080807a; border-radius: 5px; background-image: url(<?php echo$business['ads']['adBackgroundImage']?>);">
                </div>
                <?php else : ?>
                <div id="adBox"
                    style="box-shadow: 0px 2px 3px 0px rgba(0,0,0,0.2); border: 1px solid <?php echo $business['ads']['backgroundBorderColor']; ?>; border-radius: 5px; height: 175px; margin-top: 5%; background-position: center; background-repeat: no-repeat; background-size: cover; background-image: url('<?php echo $business['ads']['adBackgroundImage'] ?>'); background-color: <?php echo $business['ads']['backgroundColor'] ?>;">
                    <div style="width: 100%; height: 100%;">
                        <div id="adLogo" style="float: left; width: 30%; ">
                            <img id="adImg" style="height: 110px; margin: 30px"
                                src="<?php echo $business['ads']['adImage'] ?>" />
                        </div>
                        <div id="adContent" style="float: right; width: 70%; margin: none; ">
                            <div id="adTitle"
                                style="color: <?php echo $business['ads']['adTitleColor'] ?>; line-height: normal; margin: 20px 0px 0px 0px; font-family: <?php echo $business['ads']['adTitleFontFamily'] ?>; text-decoration: <?php echo $business['ads']['adTitleFontStyle'] ?>; font-weight: <?php echo $business['ads']['adTitleFontStyle'] == 'none' ? 'normal' : $business['ads']['adTitleFontStyle']?>; font-style: <?php echo $business['ads']['adTitleFontStyle'] == 'none' ? 'normal' : $business['ads']['adTitleFontStyle']?>; font-size: <?php echo $business['ads']['adTitleFontSize'] ?>px; ">
                                <?php echo $business['ads']['adTitle'] ?>
                            </div>
                            <div id="adSubTitle"
                                style="line-height: normal; margin-bottom: 3%; color: <?php echo $business['ads']['adSubTitleColor'] ?>; font-family: <?php echo $business['ads']['adSubTitleFontFamily'] ?>; text-decoration: <?php echo $business['ads']['adSubTitleFontStyle'] ?>; font-weight: <?php echo $business['ads']['adSubTitleFontStyle'] == 'none' ? 'normal' : $business['ads']['adSubTitleFontStyle']?>; font-style: <?php echo $business['ads']['adSubTitleFontStyle'] == 'none' ? 'normal' : $business['ads']['adSubTitleFontStyle']?>; font-size: <?php echo $business['ads']['adSubTitleFontSize'] ?>px; ">
                                <?php echo $business['ads']['adSubTitle'] ?>
                            </div>
                            <button id="adCTA" onclick="myFunction()"
                                style="margin-left: 0px; background-color: <?php echo $business['ads']['calltoActionButtonBackgroundColor'] ?>; border-radius: 3px; display: inline-block; height: 40px; line-height: 40px; text-align: center; min-width: 100px; cursor: pointer; font-weight: 400; font-size: 14px; padding: 0px 30px 0px 30px; border: none; color: rgb(255,255,255); transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0s; ">
                                <span id="btnText"
                                    style="color: <?php echo $business['ads']['calltoActionButtonBorderColor'] ?>; font-family: <?php echo $business['ads']['callToActionFontFamily'] ?>; font-weight: <?php echo $business['ads']['callToActionFontStyle'] == 'none' ? 'normal' : $business['ads']['callToActionFontStyle']?>; font-size: <?php echo $business['ads']['callToActionFontSize'] ?>px; line-height: none; ">
                                    <?php echo $business['ads']['callToActionText'] ?>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>



        <?php //endif; ?>
        <?php endforeach; ?>
    </div>
    <?php 
        // $encodedBusiness = json_encode($business);
    ?>
    <?php if($LastEvaluatedKey) : ?> 
        <div id="loadMoreDiv" style="margin-top: 20px; text-align: center;">
            <div id="loadMoreOpioDivButton" onclick="return loadMore('<?php echo $business['_id'] ?>')" style="border-radius: 2px; display: inline-block; height: 40px; line-height: 40px; margin-left: 0px; text-align: center; min-width: 100px; cursor: pointer; padding: 0px 30px; font-weight: 500; font-size: 14px; color: <?php echo $buttonColorText?>; border: <?php echo $buttonBorder?>; background-color: <?php echo $buttonColor?>; position: relative; transition: all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0s; user-select: none;">
                <div style="display: inline-block; position: relative; height: 100%;">
                    Load more
            </div>
        </div>
    <?php endif; ?>

                
                <?php
            // endforeach;
        return ob_get_clean();
    }

}

?>
