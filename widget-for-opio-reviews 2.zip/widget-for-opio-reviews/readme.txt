=== Widget for OPIO Reviews ===
Author: Dhiraj Timalsina
Tags: Widget for OPIO Reviews, opio, reviews, rating, widget, google business, testimonials
Tested up to: 6.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Official way to show OPIO Reviews on WordPress site without manual code settings and other unofficial methods. Boost user trust and sales on your website!

== Description ==

This plugin displays **OPIO Reviews** on your WordPress website through a public and approved by OPIO API without crawling and other unofficial methods. With this plugin, you can be sure of the right way for showing **OPIO Reviews**.

Displaying **OPIO Rating** and Reviews on your site is the easiest and most effective way to increase your customer confidence, show stars and increase conversion!
